| Controller | First mean warning | 130% completion | 150% completion | 170% completion | 170% duration |
| --- | --- | --- | --- | --- | --- |
| Fixed-Time | 160% | 95.3% | 92.6% | 55.1% | 162.4s |
| DQN | 130% | 82.0% | 77.7% | 77.3% | 175.8s |
| PPO | 130% | 89.9% | 81.2% | 77.6% | 128.7s |
| RPPO | 150% | 93.1% | 88.9% | 82.6% | 137.3s |

Warning: first mean crossing of completion<90% or paired duration ratio>2. PPO130% and Fixed-Time160% intervals overlap the criterion. Completed-trip durations exclude unfinished trips.
