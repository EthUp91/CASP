"""Audit raw evidence first, then regenerate paper tables, selected inference and figures.
No simulator, model training, or evaluation is launched by this script.
"""
from pathlib import Path
import ast, hashlib, itertools, json, sys
import numpy as np
import pandas as pd
from scipy import stats
ROOT=Path(__file__).resolve().parents[2]
A=ROOT/'analysis_demand_stress'; HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(A))
from analyze_demand_stress import read_run,ci,ratios,thresholds
ORDER=['Fixed-Time','DQN','PPO','RPPO']; DEMANDS=list(range(100,171,10)); SEEDS=list(range(42,47))

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def md(f):
 return '\n'.join(['| '+' | '.join(map(str,f.columns))+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(map(str,r))+' |' for r in f.itertuples(index=False,name=None)])

def main():
 HERE.mkdir(exist_ok=True); (HERE/'data').mkdir(exist_ok=True)
 raw=A/'results/raw'; expected={(c,d,s) for c in ORDER for d in DEMANDS for s in SEEDS}
 files=list(raw.rglob('manifest.json')); rows=[];manifests=[];rate_sets=[]
 assert not list(raw.rglob('failure.json')),'Failure markers in primary raw tree'
 for p in files:
  row,m,rates=read_run(p.parent);rows.append(row);manifests.append(m);rate_sets.append(rates)
 runs=pd.DataFrame(rows);keys=list(zip(runs.controller,runs.demand_pct,runs.seed))
 assert len(keys)==160 and len(set(keys))==160 and set(keys)==expected
 assert set(runs.stop_time_s)=={3601.0}
 assert len({json.dumps(m['protocol'],sort_keys=True) for m in manifests})==1
 protocol=manifests[0]['protocol']
 for field,p in [('config_sha256',ROOT/'cfg/gongguanacc.sumocfg'),('environment_sha256',ROOT/'script/gongguanroundaboutenv.py'),('generator_sha256',ROOT/'script/generate_train_rou.py'),('network_sha256',ROOT/'net/gongguan_fixed_signal_blocking_cleaned.net.xml')]:
  assert protocol[field]==sha(p)
 for d in DEMANDS:
  for s in SEEDS:
   selected=[m for m in manifests if m['demand_pct']==d and m['seed']==s]
   assert len({m['output_sha256']['demand.rou.xml'] for m in selected})==1
 for s in SEEDS:
  indexes=[i for i,m in enumerate(manifests) if m['seed']==s]
  assert len({manifests[i]['route_seed'] for i in indexes})==1
  base=next(i for i in indexes if manifests[i]['demand_pct']==100)
  for i in indexes:
   assert rate_sets[i].keys()==rate_sets[base].keys()
   for k,v in rate_sets[base].items():assert abs(rate_sets[i][k]-v*manifests[i]['demand_pct']/100)<=.025
 model_provenance={}
 for c in ORDER[1:]:
  directory=A/'retraining/full'/c;m=json.loads((directory/'training_manifest.json').read_text())
  assert m['actual_timesteps']==512000 and m['status']=='completed'
  for k,p in m['artifacts'].items():assert sha(directory/Path(p).name)==m['artifact_sha256'][k]
  assert all(x['artifact_sha256']==m['artifact_sha256'] for x in manifests if x['controller']==c)
  model_provenance[c]=m['artifact_sha256']
 source=(A/'run_demand_stress_test.py').read_text();tree=ast.parse(source)
 methods=[n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)]
 assert 'learn' not in methods and 'train' not in methods
 assert 'normalizer.training=False;normalizer.norm_reward=False' in source and 'deterministic=True' in source
 previous=pd.read_csv(A/'results/retrained_comparison/run_metrics.csv').set_index(['controller','demand_pct','seed'])
 fresh=runs.set_index(['controller','demand_pct','seed']).loc[previous.index]
 for column in previous.select_dtypes(include='number').columns:np.testing.assert_allclose(fresh[column],previous[column],rtol=1e-11,atol=1e-10)
 saved=pd.read_csv(A/'results/retrained_comparison/summary_metrics.csv')
 for _,r in saved.iterrows():
  v=ci(runs[(runs.controller==r.controller)&(runs.demand_pct==r.demand_pct)][r.metric])
  for k in ['mean','sd','se','ci95_low','ci95_high']:np.testing.assert_allclose(v[k],r[k],rtol=1e-10,atol=1e-10)
 assert set(saved.n)=={5}
 validation={'status':'PASS','expected_runs':160,'validated_runs':160,'seed_blocks':SEEDS,'demands':DEMANDS,'controllers':ORDER,'failed_or_partial_runs':0,'stop_time_seconds':3601,'all_raw_output_hashes_valid':True,'identical_matched_demands':True,'uniform_protocol_and_metric_definitions':True,'fresh_metrics_match_saved_metrics':True,'CIs_recomputed_from_five_seed_means':True,'no_training_calls_in_evaluator':True,'model_hashes_match_final_trained_pairs':True,'model_artifacts':model_provenance,'evaluation_source_sha256':sha(A/'run_demand_stress_test.py')}
 (HERE/'VALIDATION_REPORT.json').write_text(json.dumps(validation,indent=2))
 (HERE/'VALIDATION_REPORT.md').write_text('''# Final-data validation: PASS

- All160 expected controller × demand × seed runs exist, without duplicates,
  missing runs, failure markers or partial manifests.
- Demands100–170% and seeds42–46 are matched; demand XML hashes are identical
  across controllers at each block. Flow composition and matched noise draws
  remain fixed across scaling levels (rounding tolerance0.025veh/hour).
- Every simulation ends at3601s with identical source/config/network hashes,
  metric definitions and software-version records. Every recorded raw-output
  hash is verified; loaded/inserted/completed/unfinished/undeparted accounting
  is reconciled against SUMO statistics, including removed-trip handling.
- Completed-trip duration/waiting/time loss exclude horizon-censored trips;
  completion divides arrivals by all loaded demand, including undeparted demand.
- Metrics were freshly reconstructed from raw XML/manifests and match all saved
  seed-level numbers. All saved means/SD/SE/95% CIs match recomputation from
  five seed-level observations (Student-t, df4), never pooled vehicle samples.
- All evaluation artifact hashes match final512,000-step training pairs.
  The evaluator contains no learn/train calls, uses deterministic inference,
  frozen observation normalization, and disabled reward normalization.

Limits: this verifies saved outputs and the current evaluator, not an unrecorded
historical execution trace. Seed independence is conditional on the fixed policy
and generator; seed labels are not claimed to be held out of training. Only one
policy-training seed exists. Socket/libsumo validation evidence is retained in
`../retraining/validation/`; backend equivalence was checked on representative
seeded trajectories, not every policy/demand combination.
''')
 # Validation is saved before any further inference or figure generation.
 runs.sort_values(['controller','demand_pct','seed']).to_csv(HERE/'data/seed_level_metrics.csv',index=False)
 metrics=['travel_time_s','waiting_time_s','time_loss_s','average_speed_m_s','trip_average_speed_m_s','average_queue_vehicles','completed_trip_ratio','unfinished_trip_ratio','average_step_reward','average_phase_duration_s']
 long=[];wide=[];changes=[];human=[]
 lower={'travel_time_s','waiting_time_s','time_loss_s','average_queue_vehicles','unfinished_trip_ratio'}
 higher={'average_speed_m_s','trip_average_speed_m_s','completed_trip_ratio'}
 fixed=runs[runs.controller=='Fixed-Time'].set_index(['demand_pct','seed'])
 for c in ORDER:
  base=runs[(runs.controller==c)&(runs.demand_pct==100)].set_index('seed')
  for d in DEMANDS:
   g=runs[(runs.controller==c)&(runs.demand_pct==d)].set_index('seed').loc[SEEDS]
   row={'controller':c,'demand_pct':d};display={'Controller':c,'Demand':f'{d}%'}
   for metric in metrics:
    st=ci(g[metric]);long.append(dict(controller=c,demand_pct=d,metric=metric,**st))
    row.update({metric+'_'+k:v for k,v in st.items()})
    for refname,ref in [('own_100',base),('Fixed-Time',fixed.loc[d].loc[SEEDS])]:
     delta=ci(g[metric]-ref[metric]);ratio=ci(100*(g[metric]/ref[metric]-1)) if metric!='average_step_reward' else None
     record=dict(controller=c,demand_pct=d,metric=metric,reference=refname,**{'difference_'+k:v for k,v in delta.items()})
     if ratio is not None:record.update({'relative_change_pct_'+k:v for k,v in ratio.items()})
     if refname=='Fixed-Time' and metric in lower|higher:
      imp=ci((1 if metric in lower else -1)*100*(ref[metric]-g[metric])/ref[metric]);record.update({'improvement_pct_'+k:v for k,v in imp.items()})
     changes.append(record)
   for label,metric,factor in [('Duration [95% CI],s','travel_time_s',1),('Wait,s','waiting_time_s',1),('Time loss,s','time_loss_s',1),('Speed,m/s','average_speed_m_s',1),('Queue,veh','average_queue_vehicles',1),('Complete,%','completed_trip_ratio',100),('Incomplete,%','unfinished_trip_ratio',100),('Reward/step','average_step_reward',1),('Phase proxy,s','average_phase_duration_s',1)]:
    st=ci(g[metric]);display[label]=f'{st["mean"]*factor:.2f}'+(f' [{st["ci95_low"]:.2f}, {st["ci95_high"]:.2f}]' if metric=='travel_time_s' else '')
   wide.append(row);human.append(display)
 pd.DataFrame(wide).to_csv(HERE/'data/complete_results_wide.csv',index=False)
 pd.DataFrame(long).to_csv(HERE/'data/complete_results_long.csv',index=False)
 pd.DataFrame(changes).to_csv(HERE/'data/paired_changes.csv',index=False)
 (HERE/'COMPLETE_RESULTS.md').write_text('# Complete controller × demand table\n\n'+md(pd.DataFrame(human))+'\n\nAll other intervals, SD and SE are in the long/wide CSVs. Speed here is the original step-averaged in-network speed; completed-trip routeLength/duration speed is separately retained. Reward is raw source utility, not a traffic-delay metric; Fixed-Time does not increment the source switch penalty counter. The phase proxy includes green-to-green intervals/yellow and a terminal interval, not pure green duration. Neither is used to rank robustness.\n')
 degradation,improvement=ratios(runs);thr,adj,seedthr=thresholds(runs,degradation,.9,25,5)
 thr.to_csv(HERE/'data/robustness_thresholds.csv',index=False);adj.to_csv(HERE/'data/adjacent_queue_growth.csv',index=False);seedthr.to_csv(HERE/'data/seed_thresholds.csv',index=False)
 # Three selected paired completion contrasts; no fishing over all demand/metric cells.
 tests=[]
 for c,ref,d in [('RPPO','Fixed-Time',160),('RPPO','Fixed-Time',170),('RPPO','PPO',170)]:
  x=runs[(runs.controller==c)&(runs.demand_pct==d)].set_index('seed').loc[SEEDS].completed_trip_ratio
  y=runs[(runs.controller==ref)&(runs.demand_pct==d)].set_index('seed').loc[SEEDS].completed_trip_ratio
  dif=(x-y).to_numpy()*100;st=ci(dif);test=stats.ttest_rel(x,y)
  perm=[abs(np.mean(dif*np.array(signs))) for signs in itertools.product([-1,1],repeat=5)]
  exact=sum(v>=abs(dif.mean())-1e-12 for v in perm)/len(perm)
  tests.append(dict(controller=c,reference=ref,demand_pct=d,metric='completion_difference_percentage_points',**st,t_statistic=float(test.statistic),paired_t_p=float(test.pvalue),cohen_dz=st['mean']/st['sd'],sign_flip_p=exact))
 p=np.array([x['paired_t_p'] for x in tests]);idx=np.argsort(p);adjusted=np.maximum.accumulate(p[idx]*np.arange(len(p),0,-1))
 for i,v in zip(idx,adjusted):tests[int(i)]['paired_t_p_holm']=min(float(v),1.)
 tf=pd.DataFrame(tests);tf.to_csv(HERE/'data/selected_paired_tests.csv',index=False)
 (HERE/'STATISTICS.md').write_text('''# Selected paired inference

Three two-sided completion contrasts were selected to address the stated questions:
RPPO–Fixed-Time at160/170%, and RPPO–PPO at170%. Unit: matched traffic seed.
Differences are percentage points; intervals are unadjusted Student-t95% intervals
on five paired differences (df4). Holm controls the three paired-t p-values.
Cohen dz uses the SD of paired differences and is unstable with n5.
Exact sign-flip sensitivity enumerates all32 sign assignments; its minimum
possible two-sided p-value is0.0625. It assumes sign exchangeability under the
null and does not represent randomized causal controller assignment.

'''+md(tf.round(5))+'''

The RPPO–PPO completion difference has a positive t interval and passes the
exploratory Holm-adjusted paired t test, conditional on normal paired differences.
It does not reach5% under the exact sign-flip sensitivity (n5 cannot do so).
RPPO–Fixed-Time completion differences do not provide a clear five-seed
inferential advantage. No omnibus algorithm superiority is claimed. The t CIs
can be sensitive to a single extreme Fixed-Time seed; a normality test with
five observations would not resolve that limitation. Baseline degradation and
other cells are descriptive paired intervals rather than additional tests.
''')
 compact=[]
 for c in ORDER:
  warning=thr.set_index('controller').loc[c,'first_primary_threshold_demand_pct']
  row={'Controller':c,'First mean warning':f'{int(warning)}%'}
  for d in [130,150,170]:row[f'{d}% completion']=f'{runs[(runs.controller==c)&(runs.demand_pct==d)].completed_trip_ratio.mean()*100:.1f}%'
  row['170% duration']=f'{runs[(runs.controller==c)&(runs.demand_pct==170)].travel_time_s.mean():.1f}s';compact.append(row)
 table=pd.DataFrame(compact);table.to_csv(HERE/'data/paper_table.csv',index=False)
 (HERE/'PAPER_TABLE.md').write_text(md(table)+'\n\nWarning: first mean crossing of completion<90% or paired duration ratio>2. PPO130% and Fixed-Time160% intervals overlap the criterion. Completed-trip durations exclude unfinished trips.\n')
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 plt.rcParams.update({'font.size':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
 styles={'Fixed-Time':('black','o'),'DQN':('#0072B2','s'),'PPO':('#D55E00','^'),'RPPO':('#009E73','D')}
 figdir=HERE/'figures';figdir.mkdir(exist_ok=True)
 for metric,name,label,factor in [('travel_time_s','figure1_duration','Completed-trip duration (s)',1),('completed_trip_ratio','figure2_completion','Completed demand (%)',100),('average_queue_vehicles','figure3_queue','Mean approach queue (vehicles)',1)]:
  fig,ax=plt.subplots(figsize=(3.45,2.5))
  for c in ORDER:
   values=[ci(runs[(runs.controller==c)&(runs.demand_pct==d)][metric]) for d in DEMANDS];color,marker=styles[c]
   ax.plot(DEMANDS,[v['mean']*factor for v in values],color=color,marker=marker,markersize=3,linewidth=1,label=c)
   ax.fill_between(DEMANDS,[v['ci95_low']*factor for v in values],[v['ci95_high']*factor for v in values],color=color,alpha=.15,linewidth=0)
  if metric=='completed_trip_ratio':ax.axhline(90,color='.5',linestyle='--',linewidth=.7)
  ax.set_ylim(bottom=0);ax.set_xlim(98,172)
  if metric=='completed_trip_ratio':ax.set_ylim(0,102)
  ax.set_xlabel('Demand (% of generator baseline)');ax.set_ylabel(label);ax.set_xticks(DEMANDS)
  ax.legend(fontsize=6.8,frameon=False,ncol=2,loc='best');fig.tight_layout(pad=.4)
  for ext in ['pdf','png']:fig.savefig(figdir/f'{name}.{ext}',dpi=300)
  plt.close(fig)
 # Normalized duration is retained as supplementary evidence, not another main figure.
 fig,ax=plt.subplots(figsize=(3.45,2.5))
 for c in ORDER:
  vals=[ci(degradation[(degradation.controller==c)&(degradation.demand_pct==d)&(degradation.metric=='travel_time_s')].relative_value) for d in DEMANDS];color,marker=styles[c]
  ax.plot(DEMANDS,[v['mean'] for v in vals],color=color,marker=marker,markersize=3,linewidth=1,label=c)
  ax.fill_between(DEMANDS,[v['ci95_low'] for v in vals],[v['ci95_high'] for v in vals],color=color,alpha=.15,linewidth=0)
 ax.axhline(2,color='.5',linestyle='--',linewidth=.7);ax.set_ylim(bottom=0);ax.set_xticks(DEMANDS)
 ax.set_xlabel('Demand (% of generator baseline)');ax.set_ylabel('Duration / own 100% duration');ax.legend(fontsize=6.8,frameon=False,ncol=2);fig.tight_layout(pad=.4)
 for ext in ['pdf','png']:fig.savefig(figdir/f'supplement_normalized_duration.{ext}',dpi=300)
 plt.close(fig)
 print('Validation PASS:160 raw runs, matched hashes, fresh seed metrics and CIs. No training.');print(tf.round(5).to_string(index=False));print(table.to_string(index=False))
if __name__=='__main__':main()
