# Framing and critical assessment

## Recommended framing

Preferred title: **Demand-Dependent Operating Ranges of Traffic-Signal Controllers at Gongguan Roundabout**.

Alternatives:

1. Traffic-Signal Robustness Beyond a Single High-Demand Scenario: A Gongguan Stress Test
2. Delay, Completion, and Demand: Stress Testing Fixed-Time and Reinforcement-Learning Signal Control

Question: How do operating ranges and degradation patterns of source-based Fixed-Time,
DQN, PPO and RPPO change with increasing demand, and do rankings depend on the metric?

Gap: Selected-scenario aggregate comparisons do not establish demand-response curves
or how horizon censoring changes judgments of operational robustness.

Novelty: A matched, progressively scaled demand evaluation identifies service warnings
and demand/metric-dependent tradeoffs for existing controller code, without a new algorithm.

Contributions:

- Eight-level,160-run matched demand-response curves beyond a selected130% case.
- Practical service-warning regions with seed-level uncertainty and total-demand accounting.
- Verified changes in controller ordering across demand and metrics, distinguishing
  conditional delay from total-demand service.
- Reproducible source-based policy provenance and transparent limits on historical replication.

Practical contribution: select a controller for an explicit demand range and service
objective; monitor completion and queues alongside completed-trip delay.

Main conclusion: D and F are supported—Fixed-Time remains competitive at moderate
loads, while no universal controller ranking follows. RPPO has the highest extreme-load
mean completion but not the latest warning or a clear five-seed completion advantage
against Fixed-Time. Conclusions concern replacement policies, not published weights.

## Questions A–H: what is supported?

A. Demand ranking changes: Fixed-Time has the highest mean completion100–150%,
RPPO at160/170%. DQN beats PPO on mean duration at100/110%, but is slower thereafter.
These are observed orderings, not eight sets of significance tests.

B. Metric ranking changes: at170%, RPPO has the largest completion while PPO has
lower mean duration and queue; neither dominates the other. Completion is meaningful
for all demand, while delay/queue exclude some unmet demand.

C. RPPO completion robustness: warning150% is later than DQN/PPO130%, earlier
than Fixed-Time160%. RPPO's170% completion exceeds PPO by5.01pp with positive
paired t CI and Holm p0.0011, but exact sign-flip p0.0625. Against Fixed-Time,
mean+27.53pp has CI−4.58 to59.65 and Holm p0.152. No universal advantage is established.

D. Fixed-Time moderate demand: yes, descriptively highest completion through150%,
with favorable delay at many levels. At130% RPPO delay is not clearly different,
but RPPO serves2.26pp less demand (paired CI−2.96 to−1.56).

E. PPO lower delay with less completion: numerical extreme-load delay is lower
than RPPO by8.51s at170%, but paired difference CI spans zero. Its queue is lower
by12.23veh (paired CI5.19–19.26). Its completion is lower by5.01pp. This is a
controller-level metric tradeoff, not proof of causal sacrifice for individual vehicles.

F. DQN inferiority: not uniform. At100% DQN has slightly lower queue than
Fixed-Time and lower delay than PPO; at170% it completes more mean demand than
Fixed-Time. It deteriorates strongly at120–150% and is not exceptionally robust.

G. Substantial degradation: DQN first mean primary warning130% (one seed120%);
PPO130% (seed warnings130/140%); RPPO150% (all five seeds); Fixed-Time160%
(all five seeds via either criterion). Queue growth occurs earlier and is not
itself a primary failure rule. Threshold intervals overlap for PPO130% and
Fixed-Time160%; RPPO150% completion upper CI89.95% is close to90%.

H. Nonlinear/tipping region: Fixed-Time completion92.64→81.88→55.11% and
queue53.91→83.21→140.20 from150→160→170% support an abrupt deterioration region.
DQN also drops sharply at120→130%; RPPO/PPO are smoother. A fitted critical
capacity or unique physical bifurcation is not justified by eight levels/five seeds.

## Figure selection

Use three main figures: duration, total-demand completion, approach queue.
Completion is the central story; delay establishes the censoring/metric tradeoff,
and queue substantiates the congestion region. All start at zero and carry
seed-level95% bands. Keep normalized duration supplementary: PPO's worse100%
baseline makes relative stability an incomplete performance judgment.

## What belongs in four pages?

Main paper must state plain-DQN naming, missing original pairs/new policies,
512,000-step budget, independent-worker correction, CPU/backend adaptations,
paired seeds, censoring and single-training-seed scope. Include the130% failure
to reproduce supplied training-log ordering and unresolved historical provenance.
Put full constructor settings, model/source hashes, timing/resource measurements,
backend diagnostics, complete32-cell tables and extra statistics in the package.
Do not present old training summaries as verified publication test-table numbers.

## Reviewer-style assessment

- **Enough novelty?** Modest but defensible for a practitioner/short conference
  case study. Stronger as operational evaluation and reproducibility than as
  algorithm research. Venue fit matters; no acceptance claim is made.
- **Strongest contribution:** completion-aware demand curves show that the latest
  warning, smallest conditional delay and greatest extreme-load throughput need
  not select the same controller.
- **Biggest weakness:** one training seed with replacement policies and necessary
  orchestration changes prevents general algorithm ranking or exact historical
  replication. Five traffic seeds limit robust inferential power.
- **Most publishable result:** Fixed-Time's later mean warning versus RPPO's
  better extreme-load mean completion, with PPO's conditional-delay/queue tradeoff
  and explicit uncertainty rather than an asserted winner.
- **Claims to avoid:** RPPO universally dominates; PPO definitely reduces delay
  for all demanded vehicles; precise network capacity/tipping point; actual Double
  DQN; exact published reproduction; proof that the published paper is wrong.
- **Additional experiment absolutely necessary?** **No**, for the narrow,
  explicitly conditional case-study framing. The existing evidence supports
  descriptive operating-region tradeoffs. A general algorithm superiority claim
  would require more evidence, but that claim should be removed rather than adding
  experiments merely to pursue it. No new training/simulation was run here.

Before submission, complete the original publication's bibliographic citation,
replace author metadata, confirm the venue's four-page template, and ensure the
main claims retain small-sample qualifications. These are editorial requirements,
not new experimental work.
