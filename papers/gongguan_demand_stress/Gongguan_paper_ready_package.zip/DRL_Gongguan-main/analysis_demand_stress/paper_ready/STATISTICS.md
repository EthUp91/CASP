# Selected paired inference

Three two-sided completion contrasts were selected to address the stated questions:
RPPO–Fixed-Time at160/170%, and RPPO–PPO at170%. Unit: matched traffic seed.
Differences are percentage points; intervals are unadjusted Student-t95% intervals
on five paired differences (df4). Holm controls the three paired-t p-values.
Cohen dz uses the SD of paired differences and is unstable with n5.
Exact sign-flip sensitivity enumerates all32 sign assignments; its minimum
possible two-sided p-value is0.0625. It assumes sign exchangeability under the
null and does not represent randomized causal controller assignment.

| controller | reference | demand_pct | metric | n | mean | sd | se | ci95_low | ci95_high | t_statistic | paired_t_p | cohen_dz | sign_flip_p | paired_t_p_holm |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RPPO | Fixed-Time | 160 | completion_difference_percentage_points | 5 | 3.58601 | 9.3567 | 4.18444 | -8.03187 | 15.20388 | 0.85699 | 0.43976 | 0.38326 | 0.5625 | 0.43976 |
| RPPO | Fixed-Time | 170 | completion_difference_percentage_points | 5 | 27.53493 | 25.86723 | 11.56818 | -4.58348 | 59.65334 | 2.38023 | 0.07597 | 1.06447 | 0.125 | 0.15194 |
| RPPO | PPO | 170 | completion_difference_percentage_points | 5 | 5.00853 | 1.00632 | 0.45004 | 3.75902 | 6.25805 | 11.12909 | 0.00037 | 4.97708 | 0.0625 | 0.00111 |

The RPPO–PPO completion difference has a positive t interval and passes the
exploratory Holm-adjusted paired t test, conditional on normal paired differences.
It does not reach5% under the exact sign-flip sensitivity (n5 cannot do so).
RPPO–Fixed-Time completion differences do not provide a clear five-seed
inferential advantage. No omnibus algorithm superiority is claimed. The t CIs
can be sensitive to a single extreme Fixed-Time seed; a normality test with
five observations would not resolve that limitation. Baseline degradation and
other cells are descriptive paired intervals rather than additional tests.
