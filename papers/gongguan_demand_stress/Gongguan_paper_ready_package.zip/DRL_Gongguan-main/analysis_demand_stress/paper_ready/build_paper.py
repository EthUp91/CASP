"""Render the reviewed Markdown draft as a generic four-page two-column PDF.
This is a layout draft, not a claim of compliance with an unspecified venue template.
"""
from pathlib import Path
import re, subprocess, json
HERE=Path(__file__).resolve().parent
s=(HERE/'paper_draft.md').read_text()
title=s.splitlines()[0][2:]
abstract=re.search(r'\*\*Abstract:\*\* (.*?)\n',s).group(1)
keywords=re.search(r'\*\*Keywords:\*\* (.*?)\n',s).group(1)
assert len(abstract.split())<=100
body=s[s.index('## 1. Introduction'):s.index('## Figure and table captions')]
references=s[s.index('## References'):]
figures={
 'Figure 1 shows why':('figure1_duration',r'Completed-trip duration. Five-seed means and marginal 95\% t intervals; unfinished demand is excluded. Read with Fig.~2.'),
 'Figure 2 identifies distinct':('figure2_completion',r'Completed/loaded demand, including undeparted vehicles. Shading: five-seed 95\% t intervals; dashed line: 90\% warning.'),
 '### 3.2 Demand- and metric-dependent rankings':('figure3_queue',r'Time-averaged halted vehicles on designated approaches, with five-seed 95\% t intervals. Undeparted demand is not measured here.')}
for trigger,(filename,caption) in figures.items():
 figure='\n```{=latex}\n\\begin{figure}[t]\n\\centering\n\\includegraphics[width=\\columnwidth]{figures/'+filename+'.pdf}\n\\caption{'+caption+'}\n\\end{figure}\n```\n\n'
 body=body.replace(trigger,figure+trigger)
table=r'''
```{=latex}
\begin{table}[t]
\centering
\caption{First mean warning; completion (C,\%) and completed-trip duration (T,s). PPO130\% and Fixed-Time160\% warning intervals overlap the criteria.}
\small
\setlength{\tabcolsep}{3pt}
\begin{tabular}{lrrrrr}
\toprule
Controller & Warning & C130 & C150 & C170 & T170\\
\midrule
Fixed-Time &160\%&95.3&92.6&55.1&162.4\\
DQN &130\%&82.0&77.7&77.3&175.8\\
PPO &130\%&89.9&81.2&77.6&128.7\\
RPPO &150\%&93.1&88.9&82.6&137.3\\
\bottomrule
\end{tabular}
\end{table}
```
'''
body=body.replace('### 3.1 Operating ranges and degradation',table+'\n### 3.1 Operating ranges and degradation')
text=(body+'\n'+references).replace('−','-')
(HERE/'paper_body.md').write_text(text)
subprocess.run(['pandoc',str(HERE/'paper_body.md'),'--from','markdown','--to','latex','--output',str(HERE/'paper_body.tex')],check=True)
header=r'''\documentclass[10pt,twocolumn,letterpaper]{article}
\usepackage[margin=0.75in,top=0.8in,bottom=0.8in,columnsep=0.24in]{geometry}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{times,microtype,graphicx,booktabs,amsmath,amssymb}
\usepackage[hidelinks]{hyperref}
\setcounter{secnumdepth}{0}
\setlength{\parindent}{1em}
\setlength{\parskip}{0pt}
\setlength{\textfloatsep}{9pt plus2pt minus2pt}
\setlength{\floatsep}{8pt plus2pt minus2pt}
\setlength{\intextsep}{8pt plus2pt minus2pt}
\providecommand{\tightlist}{\setlength{\itemsep}{0pt}\setlength{\parskip}{0pt}}
\title{TITLE}
\author{Anonymous draft}
\date{}
\begin{document}
\maketitle
\begin{abstract}
ABSTRACT
\end{abstract}
\noindent\textbf{Keywords:} KEYWORDS
\input{paper_body.tex}
\end{document}
'''
# Abstract and metadata contain literal percentages; escape only those fields.
header=header.replace('TITLE',title).replace('ABSTRACT',abstract.replace('%',r'\%')).replace('KEYWORDS',keywords)
(HERE/'paper_draft.tex').write_text(header)
for _ in range(2):
 result=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','paper_draft.tex'],cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (HERE/'latex_build_output.txt').write_text(result.stdout)
 if result.returncode:raise RuntimeError(result.stdout[-3500:])
info=subprocess.check_output(['pdfinfo',str(HERE/'paper_draft.pdf')],text=True)
pages=int(re.search(r'Pages:\s+(\d+)',info).group(1))
log=(HERE/'paper_draft.log').read_text()
audit={'abstract_words':len(abstract.split()),'markdown_words':len(s.split()),'PDF_pages':pages,'generic_template':'10pt, two-column US Letter,0.75in side margins','reference_1_metadata_unresolved':True,'overfull_hbox_count':log.count('Overfull \\hbox')}
(HERE/'layout_validation.json').write_text(json.dumps(audit,indent=2))
print(json.dumps(audit,indent=2))
if pages>4:raise ValueError('Draft exceeds four pages: edit prose, not font size.')
