# Validated paper package

No new training or simulation was run. All160 original completed runs were
re-read and verified before analysis and drafting.

## Start here

- `paper_draft.pdf`: compiled four-page two-column draft, including references.
- `paper_draft.md`: editable academic prose,88-word abstract, five keywords,
  figure/table captions and limitations.
- `paper_draft.tex`, `paper_body.tex`, `build_paper.py`: editable LaTeX and
  reproducible layout generation. Generic10pt US Letter, not a venue template.
- `SCIENTIFIC_ASSESSMENT.md`: three titles, question/gap/novelty/contributions,
  all eight scientific questions, figure selection and reviewer assessment.
- `VALIDATION_REPORT.md/json`:160-run raw-data, pairing, accounting, artifact,
  source-code and independent seed-level CI audit.
- `COMPLETE_RESULTS.md/html`: human-readable32-cell controller × demand table.
- `PAPER_TABLE.md`: one compact paper table.
- `STATISTICS.md`: three selected paired completion comparisons, Holm correction,
  effect sizes and exact sign-flip sensitivity. No significance fishing.

## Data and figures

`data/seed_level_metrics.csv` preserves160 unpooled runs.
`complete_results_long.csv` and `complete_results_wide.csv` contain every
requested metric's mean/SD/SE/95%CI, including both speed definitions.
`paired_changes.csv` retains per-metric paired absolute and relative changes
against own100% and same-demand Fixed-Time. Cost/benefit improvement directions
are explicit. Reward percentages are omitted because negative-valued utility
has no meaningful percentage-improvement denominator; raw differences remain.
Phase/reward comparisons are diagnostics, not robustness rankings.
`robustness_thresholds.csv`, `seed_thresholds.csv`, `adjacent_queue_growth.csv`,
`selected_paired_tests.csv` and `paper_table.csv` provide complete machine-readable
threshold/inference evidence.

Main figures: `figure1_duration`, `figure2_completion`, `figure3_queue`.
All have PDF/vector and300dpi PNG versions, consistent markers/controller names,
zero-origin axes and five-seed95%CI bands. Normalized duration is supplementary:
its denominator hides PPO's worse100% absolute baseline and is redundant for
this four-page story. Figure bands are marginal, not simultaneous intervals.

## Reproduce without new experiments

From `/workspace/DRL_Gongguan-main`:

```bash
export MPLCONFIGDIR=/tmp/demand-stress-mpl
/workspace/mode-specific-venv/bin/python analysis_demand_stress/paper_ready/prepare_package.py
/workspace/mode-specific-venv/bin/python analysis_demand_stress/paper_ready/build_paper.py
pandoc analysis_demand_stress/paper_ready/COMPLETE_RESULTS.md --standalone --metadata title='Complete demand-stress results' --output analysis_demand_stress/paper_ready/COMPLETE_RESULTS.html
```

The existing Python environment supplies numpy/pandas/scipy/matplotlib. The PDF
build additionally requires `pandoc`, `pdflatex`, `pdfinfo` and standard LaTeX
packages(times,geometry,microtype,graphicx,booktabs,amsmath,hyperref), available in
the current environment. No GPU or running SUMO instance is needed for this stage.

For a downloaded copy, extract `Gongguan_retrained_stress_results.zip`,
`Gongguan_retrained_models.zip` and `Gongguan_paper_ready_package.zip` into the
same directory. Model binaries are needed only for the audit's saved-file hash
checks, not to compute statistics or read the paper. Original raw outputs and
trained pairs remain in the previous two bundles; the paper bundle adds analysis
outputs and editable manuscript files. Paths are relative to the extracted project.

## Provenance and submission limits

These are newly trained source-based replacements, not recovered published
weights. The original label DDQN actually calls SB3 DQN. Independent SUMO
workers correct original shared-connection vectorization; CPU/backend/path/RNG
adaptations are documented in `../retraining/README.md`. One training seed/five
traffic seeds restrict generalization and robust inferential power. The paper
includes these limits and the unreproduced supplied training-log130% pattern.
Original published numerical test-table values were not supplied.

**No additional experiment is necessary for the limited descriptive case-study
claim.** Do not submit a general algorithm-superiority or exact-reproduction claim.
Before submission, complete Reference1's author/year/venue/identifier, replace
anonymous author metadata, and apply the actual venue template. The current
PDF is a reviewed generic four-page layout, not final venue-formatted submission.
