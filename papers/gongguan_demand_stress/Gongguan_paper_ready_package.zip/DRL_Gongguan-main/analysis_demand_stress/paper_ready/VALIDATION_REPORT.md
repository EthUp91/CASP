# Final-data validation: PASS

- All160 expected controller × demand × seed runs exist, without duplicates,
  missing runs, failure markers or partial manifests.
- Demands100–170% and seeds42–46 are matched; demand XML hashes are identical
  across controllers at each block. Flow composition and matched noise draws
  remain fixed across scaling levels (rounding tolerance0.025veh/hour).
- Every simulation ends at3601s with identical source/config/network hashes,
  metric definitions and software-version records. Every recorded raw-output
  hash is verified; loaded/inserted/completed/unfinished/undeparted accounting
  is reconciled against SUMO statistics, including removed-trip handling.
- Completed-trip duration/waiting/time loss exclude horizon-censored trips;
  completion divides arrivals by all loaded demand, including undeparted demand.
- Metrics were freshly reconstructed from raw XML/manifests and match all saved
  seed-level numbers. All saved means/SD/SE/95% CIs match recomputation from
  five seed-level observations (Student-t, df4), never pooled vehicle samples.
- All evaluation artifact hashes match final512,000-step training pairs.
  The evaluator contains no learn/train calls, uses deterministic inference,
  frozen observation normalization, and disabled reward normalization.

Limits: this verifies saved outputs and the current evaluator, not an unrecorded
historical execution trace. Seed independence is conditional on the fixed policy
and generator; seed labels are not claimed to be held out of training. Only one
policy-training seed exists. Socket/libsumo validation evidence is retained in
`../retraining/validation/`; backend equivalence was checked on representative
seeded trajectories, not every policy/demand combination.
